# Predicting_price_of_used_cars
Course project for DS203: Introduction to programing in data science
